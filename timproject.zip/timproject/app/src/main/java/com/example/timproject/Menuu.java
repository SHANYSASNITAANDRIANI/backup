package com.example.timproject;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Menuu extends AppCompatActivity {

    ImageButton hospital, train, airport, police, Hotel, SPBU, market, restoran, londry, cafe;
    DatabaseHelper db;
    Button logout, about;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        db = new DatabaseHelper(this);

        logout = (Button)findViewById(R.id.btn_logout);
        about = (Button)findViewById(R.id.btn_home);


        Boolean checkSession = db.checkSession("ada");
        if (checkSession == false) {
            Intent loginIntent = new Intent(Menuu.this, LoginAdmin.class);
            startActivity(loginIntent);
            finish();
        }

        // logout
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean updtSession = db.upgradeSession("kosong", 1);
                if (updtSession == true) {
                    Toast.makeText(getApplicationContext(), "Berhasil Keluar", Toast.LENGTH_SHORT).show();
                    Intent loginIntent = new Intent(Menuu.this, LoginUser.class);
                    startActivity(loginIntent);
                    finish();
                }
            }
        });
        // About
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menuu.this, about.class);
                startActivity(intent);
            }
        });
        hospital = findViewById(R.id.hospital);
        hospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.google.co.id/maps/search/Rumah+Sakit+terdekat/";
                Intent A= new Intent(Intent. ACTION_VIEW);
                A.setData(Uri. parse(url));
                startActivity(A);
            }
        });
        train = findViewById(R.id.train);
        train.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.google.co.id/maps/search/stasiun+kereta+terdekat/";
                Intent A= new Intent(Intent. ACTION_VIEW);
                A.setData(Uri. parse(url));
                startActivity(A);
            }
        });
        airport = findViewById(R.id.airport);
        airport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.google.co.id/maps/search/bandara+terdekat/";
                Intent A= new Intent(Intent. ACTION_VIEW);
                A.setData(Uri. parse(url));
                startActivity(A);
            }
        });
        police = findViewById(R.id.police);
        police.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.google.co.id/maps/search/kantor+polisi+terdekat/";
                Intent A= new Intent(Intent. ACTION_VIEW);
                A.setData(Uri. parse(url));
                startActivity(A);
            }
        });
        Hotel = findViewById(R.id.Hotel);
        Hotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.google.co.id/maps/search/Hotel+Terdekat/";
                Intent A = new Intent(Intent. ACTION_VIEW);
                A.setData(Uri. parse(url));
                startActivity(A);
            }
        });
        SPBU = findViewById(R.id.SPBU);
        SPBU.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.google.co.id/maps/search/SPBU+terdekat/";
                Intent A = new Intent(Intent. ACTION_VIEW);
                A.setData(Uri. parse(url));
                startActivity(A);
            }
        });
        restoran = findViewById(R.id.restoran);
        restoran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.google.co.id/maps/search/rumah+makan+terdekat/";
                Intent A = new Intent(Intent. ACTION_VIEW);
                A.setData(Uri. parse(url));
                startActivity(A);
            }
        });
        market = findViewById(R.id.market);
        market.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.google.co.id/maps/search/supermarket+terdekat/";
                Intent A = new Intent(Intent. ACTION_VIEW);
                A.setData(Uri. parse(url));
                startActivity(A);
            }
        });
        londry = findViewById(R.id.londri);
        londry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.google.co.id/maps/search/laundry+terdekat/";
                Intent A = new Intent(Intent. ACTION_VIEW);
                A.setData(Uri. parse(url));
                startActivity(A);
            }
        });
        cafe = findViewById(R.id.cafe);
        cafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.google.co.id/maps/search/cafe+terdekat/";
                Intent A = new Intent(Intent. ACTION_VIEW);
                A.setData(Uri. parse(url));
                startActivity(A);
            }
        });
    }
}
