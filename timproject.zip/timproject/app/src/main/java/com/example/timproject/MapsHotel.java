package com.example.timproject;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.timproject.databinding.ActivityMapsHotelBinding;

public class MapsHotel extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsHotelBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps_hotel);

        binding = ActivityMapsHotelBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng TSH = new LatLng(-7.81579, 110.38257);
        mMap.addMarker(new MarkerOptions().position(TSH).title("Marker in Tjokro Style Hotel"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(TSH));

        // Add a marker in Sydney and move the camera
        LatLng HSH = new LatLng(-7.81555, 110.39131);
        mMap.addMarker(new MarkerOptions().position(HSH).title("Marker in Hotel Simply Homy Unit Kili Suci"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(HSH));

        // Add a marker in Sydney and move the camera
        LatLng TCH = new LatLng(-7.80725, 110.37049);
        mMap.addMarker(new MarkerOptions().position(TCH).title("Marker in Tasneem Convetion Hotel Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(TCH));

        // Add a marker in Sydney and move the camera
        LatLng HTY = new LatLng(-7.79611, 110.39143);
        mMap.addMarker(new MarkerOptions().position(HTY).title("Marker in Hotel Timoho Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(HTY));

        // Add a marker in Sydney and move the camera
        LatLng PPH = new LatLng(-7.77517, 110.38983);
        mMap.addMarker(new MarkerOptions().position(PPH).title("Marker in Prime Plaza Hotel Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PPH));

        // Add a marker in Sydney and move the camera
        LatLng HCL = new LatLng(-7.75663, 110.36219);
        mMap.addMarker(new MarkerOptions().position(HCL).title("Marker in Hotel Crystal Lotus"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(HCL));

        // Add a marker in Sydney and move the camera
        LatLng TRJ = new LatLng(-7.74931, 110.36151);
        mMap.addMarker(new MarkerOptions().position(TRJ).title("Marker in The Rich Jogja Hotel"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(TRJ));

        // Add a marker in Sydney and move the camera
        LatLng HIY = new LatLng(-7.74727, 110.37301);
        mMap.addMarker(new MarkerOptions().position(HIY).title("Marker in Hotel Indoluxe Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(HIY));

        // Add a marker in Sydney and move the camera
        LatLng DH = new LatLng(-7.77861, 110.39065);
        mMap.addMarker(new MarkerOptions().position(DH).title("Marker in D'Kayon Hotel"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(DH));

        // Add a marker in Sydney and move the camera
        LatLng YTH = new LatLng(-7.77195, 110.36825);
        mMap.addMarker(new MarkerOptions().position(YTH).title("Marker in Hotel Tentrem Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(YTH));
    }
}

