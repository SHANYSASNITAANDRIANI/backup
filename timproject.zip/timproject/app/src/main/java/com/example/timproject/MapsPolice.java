package com.example.timproject;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.timproject.databinding.ActivityMapsPoliceBinding;

public class MapsPolice extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsPoliceBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps_police);

        binding = ActivityMapsPoliceBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng PSUM = new LatLng(-7.81592, 110.37334);
        mMap.addMarker(new MarkerOptions().position(PSUM).title("Marker in Polsek Umbulharjo"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSUM));

        // Add a marker in Sydney and move the camera
        LatLng PSM = new LatLng(-7.81839, 110.37137);
        mMap.addMarker(new MarkerOptions().position(PSM).title("Marker in Polsek Mergangsan"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSM));

        // Add a marker in Sydney and move the camera
        LatLng PSY = new LatLng(-7.82239, 110.39898);
        mMap.addMarker(new MarkerOptions().position(PSY).title("Marker in Polsek Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSY));

        // Add a marker in Sydney and move the camera
        LatLng RSDKT = new LatLng(-7.82211, 110.39870);
        mMap.addMarker(new MarkerOptions().position(RSDKT).title("Marker in Polsek Sektor Kota Gede"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(RSDKT));

        // Add a marker in Sydney and move the camera
        LatLng PSKN = new LatLng(-7.81124, 110.40938);
        mMap.addMarker(new MarkerOptions().position(PSKN).title("Marker in Polsek Ketandan"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSKN));

        // Add a marker in Sydney and move the camera
        LatLng PSB = new LatLng(-7.81104, 110.40770);
        mMap.addMarker(new MarkerOptions().position(PSB).title("Marker in Polsek Banguntapan"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSB));

        // Add a marker in Sydney and move the camera
        LatLng PSUGM = new LatLng(-7.80127, 110.39509);
        mMap.addMarker(new MarkerOptions().position(PSUGM).title("Marker in Pos Polisi UGM"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSUGM));

        // Add a marker in Sydney and move the camera
        LatLng CSPU = new LatLng(-7.79920, 110.39021);
        mMap.addMarker(new MarkerOptions().position(CSPU).title("Marker in Civil Service Police Unit"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CSPU));

        // Add a marker in Sydney and move the camera
        LatLng PSPY = new LatLng(-7.79734, 110.37656);
        mMap.addMarker(new MarkerOptions().position(PSPY).title("Marker in Polsek Pakualaman Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSPY));

        // Add a marker in Sydney and move the camera
        LatLng PSG = new LatLng(-7.80327, 110.37011);
        mMap.addMarker(new MarkerOptions().position(PSG).title("Marker in Polsek Gondomanan"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSG));

        // Add a marker in Sydney and move the camera
        LatLng PPBW = new LatLng(-7.81390, 110.36851);
        mMap.addMarker(new MarkerOptions().position(PPBW).title("Marker in Pos Polisi Pojok Benteng Wetan"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PPBW));

        // Add a marker in Sydney and move the camera
        LatLng PSGG = new LatLng(-7.81407, 110.36270);
        mMap.addMarker(new MarkerOptions().position(PSGG).title("Marker in Polsek Gading"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSGG));

        // Add a marker in Sydney and move the camera
        LatLng PSPK = new LatLng(-7.79916, 110.36532);
        mMap.addMarker(new MarkerOptions().position(PSPK).title("Marker in Polsekta Pasar Kliwon"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSPK));

        // Add a marker in Sydney and move the camera
        LatLng GPS = new LatLng(-7.78913, 110.36119);
        mMap.addMarker(new MarkerOptions().position(GPS).title("Marker in Gedongtengen Police Station"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(GPS));

        // Add a marker in Sydney and move the camera
        LatLng PSGN = new LatLng(-7.79134, 110.38661);
        mMap.addMarker(new MarkerOptions().position(RSDKT).title("Marker in Polsek Gondokusuman"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSGN));

        // Add a marker in Sydney and move the camera
        LatLng PSD = new LatLng(-7.78812, 110.37810);
        mMap.addMarker(new MarkerOptions().position(PSD).title("Marker in Polsek Danurejan"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSD));

        // Add a marker in Sydney and move the camera
        LatLng PPLLX1 = new LatLng(-7.78304, 110.38762);
        mMap.addMarker(new MarkerOptions().position(PPLLX1).title("Marker in Pos Polisi Lalu Lintas XX1"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PPLLX1));

        // Add a marker in Sydney and move the camera
        LatLng PSDB = new LatLng(-7.78304, 110.40568);
        mMap.addMarker(new MarkerOptions().position(PSDB).title("Marker in Polsek Depok Barat"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PSDB));

        // Add a marker in Sydney and move the camera
        LatLng KKBY = new LatLng(-7.78220, 110.37544);
        mMap.addMarker(new MarkerOptions().position(KKBY).title("Marker in Kepolisian Kota Besar Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(KKBY));

        // Add a marker in Sydney and move the camera
        LatLng KSPS = new LatLng(-7.80856, 110.36506);
        mMap.addMarker(new MarkerOptions().position(KSPS).title("Marker in Keraton Sektor Police Station"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(KSPS));

        // Add a marker in Sydney and move the camera
        LatLng DLPD = new LatLng(-7.78778, 110.35963);
        mMap.addMarker(new MarkerOptions().position(DLPD).title("Marker in Dit Lantas Polda DIY"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(DLPD));

        // Add a marker in Sydney and move the camera
        LatLng PDY = new LatLng(-7.75690, 110.40057);
        mMap.addMarker(new MarkerOptions().position(PDY).title("Marker in Polda DIY Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(PDY));
    }
}
