package com.example.timproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginAdmin extends AppCompatActivity {
    Button login;
    EditText username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        login = (Button)findViewById(R.id.SignIn);


        //login
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (username.getText().toString().equalsIgnoreCase("Admin") && password.getText().toString().equalsIgnoreCase("admin")){
                Intent intent = new Intent(LoginAdmin.this, Data.class);
                startActivity(intent);
                Toast.makeText(LoginAdmin.this, "Login Admin Berhasil", Toast.LENGTH_SHORT).show();
            }
           else
            {
                Toast.makeText(LoginAdmin.this, "Gagal Login", Toast.LENGTH_SHORT).show();
            }
        }
    });

    }
}