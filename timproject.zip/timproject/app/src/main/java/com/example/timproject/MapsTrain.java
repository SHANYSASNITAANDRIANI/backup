package com.example.timproject;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.timproject.databinding.ActivityMapsTrainBinding;

public class MapsTrain extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsTrainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps_train);

        binding = ActivityMapsTrainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng SWY = new LatLng(-7.85747, 110.15802);
        mMap.addMarker(new MarkerOptions().position(SWY).title("Marker in Stasiun Wates Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(SWY));

        // Add a marker in Sydney and move the camera
        LatLng SSY = new LatLng(-7.82953, 110.22120);
        mMap.addMarker(new MarkerOptions().position(SSY).title("Marker in Stasiun Sentolo Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(SSY));

        // Add a marker in Sydney and move the camera
        LatLng SRY = new LatLng(-7.79287, 110.27814);
        mMap.addMarker(new MarkerOptions().position(SRY).title("Marker in Stasiun Rewulu Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(SRY));

        // Add a marker in Sydney and move the camera
        LatLng SPY = new LatLng(-7.77545, 110.32615);
        mMap.addMarker(new MarkerOptions().position(SPY).title("Marker in Stasiun Patukan Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(SPY));

        // Add a marker in Sydney and move the camera
        LatLng SY = new LatLng(-7.77229, 110.335971);
        mMap.addMarker(new MarkerOptions().position(SY).title("Marker in Stasiun Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(SY));

        LatLng SLY = new LatLng(-7.78020, 110.37729);
        mMap.addMarker(new MarkerOptions().position(SLY).title("Marker in Stasiun Lempuyang Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(SLY));

        LatLng SMY = new LatLng(-7.76215, 110.43316);
        mMap.addMarker(new MarkerOptions().position(SMY).title("Marker in Stasiun Maguwo Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(SMY));

        LatLng SBY = new LatLng(-7.73141, 110.50099);
        mMap.addMarker(new MarkerOptions().position(SBY).title("Marker in Stasiun Brambanan Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(SBY));

        LatLng SSTY = new LatLng(-7.69627, 110.54434);
        mMap.addMarker(new MarkerOptions().position(SSTY).title("Marker in Stasiun Sorowot Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(SSTY));

        LatLng SKY = new LatLng(-7.66698, 110.59754);
        mMap.addMarker(new MarkerOptions().position(SKY).title("Marker in Stasiun Klaten Yogyakarta"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(SKY));
    }
}

